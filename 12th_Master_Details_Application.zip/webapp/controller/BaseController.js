sap.ui.define(["sap/ui/core/mvc/Controller"],
	function (Controller) {
		"use strict";
		return Controller.extend("root.controller.BaseController", {
            			getCore: function () {
				return sap.ui.getCore();
			},
			getApp: function () {
		// return 	sap.ui.getCore().byId("mainview--idApp");
		return this.getView().getParent().getParent();
			}
		});
	});