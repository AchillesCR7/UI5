sap.ui.define(["root/controller/BaseController"
              ],
	function (Controller) {
		"use strict";
		return Controller.extend("root.controller.View2", {
			
			
			oCore: sap.ui.getCore(),

			onInit: function () {
			
				
			},
				onBack   : function(){
					var oApp = this.getApp();
				oApp.to("view1");
			}
		});
	});