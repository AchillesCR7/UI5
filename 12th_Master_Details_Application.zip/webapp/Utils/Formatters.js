sap.ui.define([], function()
{
return { 
	getName: function(inp) 
	{
		if(inp){
			return inp.toUpperCase();
		}
		
	}
	
};	
});